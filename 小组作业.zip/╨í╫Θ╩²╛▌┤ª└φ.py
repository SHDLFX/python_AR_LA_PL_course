#!/usr/bin/env python
# coding: utf-8

# In[1]:


import geopandas as gpd
import pandas as pd
import matplotlib.pyplot as plt


# In[3]:


gpd.__version__


# In[7]:


get_ipython().run_line_magic('matplotlib', 'inline')
import cartopy.crs as ccrs
import matplotlib.pyplot as plt

ax = plt.axes(projection=ccrs.PlateCarree())
ax.coastlines()

# Save the plot by calling plt.savefig() BEFORE plt.show()
plt.savefig('coastlines.pdf')
plt.savefig('coastlines.png')

plt.show()


# In[1]:


import cartopy.crs as ccrs
import matplotlib.pyplot as plt

ax = plt.axes(projection=ccrs.Mollweide())
ax.stock_img()
plt.show()


# In[9]:


import shapefile as shp
import csv
import codecs
import os

def trans_point(folder, fn, delimiter=','):
    '''transfer a csv file to shapefile'''
    # create a point shapefile
    
    
    output_shp = shp.Writer(folder + "%s.shp"%fn.split('.')[0], shp.POINT)
    # for every record there must be a corresponding geometry.
    output_shp.autoBalance = 1
    # create the field names and data type for each.you can omit fields here
    # 顺序一定要与下面的保持一致
    output_shp.field('photo_url', 'C', 50) # string, max-length
    output_shp.field('longitude', 'F', 10, 8) # float
    output_shp.field('latitude', 'F', 10, 8) # float
    output_shp.field('scene', 'C', 20) # string, max-length
    output_shp.field('scene_id', 'N')  # int
    counter = 1 # count the features
    # access the CSV file
    with codecs.open(folder + fn, 'rb', 'utf-8') as csvfile:
        reader = csv.reader(csvfile, delimiter=delimiter)
        next(reader, None) # skip the header
        #loop through each of the rows and assign the attributes to variables
        for row in reader:
            try:
                photo_url = row[0]
                lng= float(row[1])
                lat = float(row[2])
                scene = row[3]
                scene_id = int(row[4])
                output_shp.point(lng, lat) # create the point geometry
                output_shp.record(photo_url, lng, lat, scene, scene_id) # add attribute data
                if counter % 10000 == 0:
                    print("Feature " + str(counter) + " added to Shapefile.")
                counter = counter + 1
            except:
                print(row)


# In[11]:


def filePath_extraction(dirpath,fileType):
    import os
    '''funciton-以所在文件夹路径为键，值为包含该文件夹下所有文件名的列表。文件类型可以自行定义 '''
    filePath_Info={}
    i=0
    for dirpath,dirNames,fileNames in os.walk(dirpath): #os.walk()遍历目录，使用help(os.walk)查看返回值解释
       i+=1
       if fileNames: #仅当文件夹中有文件时才提取
           tempList=[f for f in fileNames if f.split('.')[-1] in fileType]
           if tempList: #剔除文件名列表为空的情况,即文件夹下存在不为指定文件类型的文件时，上一步列表会返回空列表[]
               filePath_Info.setdefault(dirpath,tempList)
    return filePath_Info

dirpath='C:\\Users\\97505\\Desktop\\123'
fileType=["csv"]
poi_paths=filePath_extraction(dirpath,fileType)
print(poi_paths)


# In[2]:


import shapefile as shp
import csv
import codecs
import os

def trans_point(folder, fn, delimiter=','):
    '''transfer a csv file to shapefile'''
    # create a point shapefile
    output_shp = shp.Writer(folder + "%s.shp"%fn.split('.')[0], shp.POINT)
    # for every record there must be a corresponding geometry.
    output_shp.autoBalance = 1
    # create the field names and data type for each.you can omit fields here
    # 顺序一定要与下面的保持一致
    output_shp.field('photo_url', 'C', 50) # string, max-length
    output_shp.field('longitude', 'F', 10, 8) # float
    output_shp.field('latitude', 'F', 10, 8) # float
    output_shp.field('scene', 'C', 20) # string, max-length
    output_shp.field('scene_id', 'N')  # int
    counter = 1 # count the features
    # access the CSV file
    with codecs.open(folder + fn,'rb', 'utf-8') as csvfile:
        reader = csv.reader(csvfile, delimiter=delimiter)
        next(reader, None) # skip the header
        #loop through each of the rows and assign the attributes to variables
        for row in reader:
            try:
                photo_url = row[0]
                lng= float(row[1])
                lat = float(row[2])
                scene = row[3]
                scene_id = int(row[4])
                output_shp.point(lng, lat) # create the point geometry
                output_shp.record(photo_url, lng, lat, scene, scene_id) # add attribute data
                if counter % 10000 == 0:
                    print("Feature " + str(counter) + " added to Shapefile.")
                counter = counter + 1
            except:
                print(row)
trans_point("D:\\123\\", "bak.csv", ",")


# In[ ]:


#csv to pkl 
import sys

if len(sys.argv)!=3:
    raise Exception("Wrong usage. Should be:  python csv2pkl.py example.csv example.pkl")

fn_in = sys.argv[1]
fn_out = sys.argv[2]

import pandas as pd

df=pd.read_csv(bak.csv)
df.to_pickle(bak1.pkl)

