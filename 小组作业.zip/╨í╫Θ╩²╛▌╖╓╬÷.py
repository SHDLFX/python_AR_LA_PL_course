#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
from scipy import stats
import plotly.express as px
import matplotlib
import math
poi_gpd=pd.read_pickle('C:\\Users\\97505\\Desktop\\code2\\bak1.pkl') #读取已经存储为.pkl格式的POI数据，其中包括geometry字段，为GeoDataFrame地理信息数据，可以通过poi_gpd.plot()迅速查看数据。
poi_gpd.plot(marker=".",markersize=5)
poi_coordinates=poi_gpd[['location_lng','location_lat']].to_numpy().T  #根据stats.gaussian_kde()输入参数要求确定数组结构
poi_coordi_kernel=stats.gaussian_kde(poi_coordinates) #核密度估计
poi_gpd['poi_kde']=poi_coordi_kernel(poi_coordinates)
poi_gpd.shopinfo=poi_gpd.shopinfo.fillna(0) 
mapbox_token='pk.eyJ1IjoicmljaGllYmFvIiwiYSI6ImNrYjB3N2NyMzBlMG8yc254dTRzNnMyeHMifQ.QT7MdjQKs9Y6OtaJaJAn0A'
px.set_mapbox_access_token(mapbox_token)
fig=px.scatter_mapbox(poi_gpd,lat=poi_gpd.location_lat, lon=poi_gpd.location_lng,color='poi_kde',color_continuous_scale=px.colors.sequential.PuBuGn, size_max=15, zoom=10)

fig.show()
poi_gpd.head()


# In[2]:


import pickle
import pprint

file=open("C:\\Users\\97505\\Desktop\\bak1(1).pkl","rb")
data=pickle.load(file)
pprint.pprint(data)
file.close()


# In[1]:


import geopandas as gpd
from matplotlib import pyplot as plt

data = gpd.read_file('C:\\Users\\97505\\Desktop\\xian.shp')#读取磁盘上的矢量文件
#data = gpd.read_file('shapefile/china.gdb', layer='province')#读取gdb中的矢量数据
print(data.crs)  # 查看数据对应的投影信息
print(data.head())  # 查看前5行数据
data.plot()
plt.show()#简单展示
poi_gpd.head()
tmp = poi_gpd.copy()
poi_gpd.dropna(axis=0,inplace=True)
poi_gpd.reset_index(drop=True, inplace=True)
poi_gpd.isna().sum()
my_poi = []
for i in tqdm(range(poi_gpd.shape[0])):
    try:
        if poi_gpd['geometry'][i].exterior.coords.xy[0][0]<312800 and poi_gpd['geometry'][i].exterior.coords.xy[0][0]>308450 and poi_gpd['geometry'][i].exterior.coords.xy[1][0]<3794800 and poi_gpd['geometry'][i].exterior.coords.xy[1][0]>3792150:
            my_poi.append(list(poi_gpd.values[i]))
    except:
        continue
# my_poi_gpd = pd.DataFrame(my_poi,columns=poi_gpd.columns)
y_poi_gpd1=gpd.GeoDataFrame(my_poi,crs=crs_32749,columns=poi_gpd.columns)
my_poi_gpd1.plot(column='Floor',figsize=(18,18),aspect=1) #提取index为'poi_0_delicacy'的行查看结果


# In[11]:


import numpy as np
import os

def compute_euclidean_distance(point, centroid):
    return np.sqrt(np.sum((point - centroid)**2))

def assign_label_cluster(distance, data_point, centroids):
    index_of_minimum = min(distance, key=distance.get)
    return [index_of_minimum, data_point, centroids[index_of_minimum]]

def compute_new_centroids(cluster_label, centroids):
    return np.array(cluster_label + centroids)/2

def iterate_k_means(data_points, centroids, total_iteration):
    label = []
    cluster_label = []
    total_points = len(data_points)
    k = len(centroids)
    
    for iteration in range(0, total_iteration):
        for index_point in range(0, total_points):
            distance = {}
            for index_centroid in range(0, k):
                distance[index_centroid] = compute_euclidean_distance(data_points[index_point], centroids[index_centroid])
            label = assign_label_cluster(distance, data_points[index_point], centroids)
            centroids[label[0]] = compute_new_centroids(label[1], centroids[label[0]])

            if iteration == (total_iteration - 1):
                cluster_label.append(label)

    return [cluster_label, centroids]

def print_label_data(result):
    print("Result of k-Means Clustering: \n")
    for data in result[0]:
        print("data point: {}".format(data[1]))
        print("cluster number: {} \n".format(data[0]))
    print("Last centroids position: \n {}".format(result[1]))

def create_centroids():
    centroids = []
    centroids.append([5.0, 0.0])
    centroids.append([45.0, 70.0])
    centroids.append([50.0, 90.0])
    return np.array(centroids)

if __name__ == "__main__":
    filename ="C:\\Users\\97505\\Desktop\\bbbb.txt"
    data_points = np.genfromtxt(filename, delimiter=",")
    centroids = create_centroids()
    total_iteration = 100
    
    [cluster_label, new_centroids] = iterate_k_means(data_points, centroids, total_iteration)
    print_label_data([cluster_label, new_centroids])
    print()


# In[16]:


# K-means Practice 
# Data x1=(1   1   4),x2=(2   2   1),x3=(7   5   6),x4=(6   5   5),x5=(1   0   2),x6=(9   8   7),x6=(4   5   7),x7=(2   1   2)
# 3D => 3 Dimention Data
# Amin Zayeromali  ==> amin.zayeromali@gmail.com  Likedin Profile : https://ir.linkedin.com/in/aminzayeromali

# Import Python Library
import pandas as pd
from sklearn.cluster import KMeans
from matplotlib import pyplot as plt

# Use Pandas lib for Create Dataframe
MyData = pd.DataFrame(
    [[1, 1, 4],
     [2, 2, 1],
     [7, 5, 6],
     [6, 5, 5],
     [1, 0, 2],
     [9, 8, 7],
     [4, 5, 7],
     [2, 1, 2]], columns=['F1', 'F2', 'F3'])

# Use Matplotlib For plotting data  
# plot 3D Data
fig = plt.figure()
ax = plt.axes(projection='3d')
ax = plt.axes(projection='3d')
ax.scatter3D(MyData['F1'], MyData['F2'], MyData['F3'])

# Use K-Means Alogrithm from Sklearn Lib
K = 2  # Number of Clusters
km = KMeans(K)  
clusts = km.fit_predict(MyData)

# Add Clusters Label to DataFrame
MyData['clusts'] = clusts
print(MyData)

# Use Matplotlib For plotting Clustered data
fig = plt.figure()
ax = plt.axes(projection='3d')
ax = plt.axes(projection='3d')
ax.scatter3D(MyData['F1'], MyData['F2'], MyData['F3'], c=MyData['clusts'])


# In[12]:


import plotly.express as px
import geopandas as gpd
poi_gpd=gpd.read_file('C:\\Users\\97505\\Desktop\\xian.shp',crs='EPSG:32749') #读取存储的.shp格式文件
poi_gpd.loc[:,:].plot(column='Floor',figsize=(55,55)) #提取index为'poi_0_delicacy'的行查看结果
my_poi = []
for i in tqdm(range(poi_gpd.shape[0])):
    try:
        if poi_gpd['geometry'][i].exterior.coords.xy[0][0]<312800 and poi_gpd['geometry'][i].exterior.coords.xy[0][0]>308450 and poi_gpd['geometry'][i].exterior.coords.xy[1][0]<3794800 and poi_gpd['geometry'][i].exterior.coords.xy[1][0]>3792150:
            my_poi.append(list(poi_gpd.values[i]))
    except:
        continue
# my_poi_gpd = pd.DataFrame(my_poi,columns=poi_gpd.columns)
my_poi_gpd1=gpd.GeoDataFrame(my_poi,crs=crs_32749,columns=poi_gpd.columns)
my_poi_gpd1.plot(column='Floor',figsize=(5,5),aspect=1) #提取index为'poi_0_delicacy'的行查看结果
from sklearn.cluster import KMeans
estimator = KMeans(n_clusters=5)
estimator.fit(my_poi_gpd1['Floor'].values.reshape(-1, 1))
label_pred = estimator.labels_
label_pred
my_poi_gpd1['lable']=label_pred
my_poi_gpd1.plot(column='lable',figsize=(5,5),aspect=10)
my_poi_gpd1.head()


# In[21]:


# -*- coding: utf-8 -*-

import shapefile# 使用pyshp

file = shapefile.Reader("C:\\Users\\97505\\Desktop\\xian.shp")#读取
#读取元数据
print(str(file.shapeType))  # 输出shp类型
print(file.encoding)# 输出shp文件编码
print(file.bbox)  # 输出shp的文件范围（外包矩形）
print(file.numRecords)  # 输出shp文件的要素数据
print(file.fields)# 输出所有字段信息
# print(file.records())  # 输出所有属性表

